<?php


include ('../script/SCRIPTconnect.php');
include ('../script/SCRIPTsession.php');
include ('../script/SCRIPTinclude.php');
include ('../admin/admin_header.php');
/**/        $logpage = basename(__FILE__);          // ##

echo "fTip Dump #002 - 2.Bundesliga Paarungen 2004/05<br><br>";



if (!$force) {
    $spruch  = "SELECT id FROM wettkampf WHERE";
    $spruch .= " saison = '2004/2005' AND liga_art_id = '4'";
    $result = mysql_query($spruch, $db);
    $row = mysql_fetch_array($result, MYSQL_ASSOC);
    $schonda = $row['id'];
    if ($schonda != '') {
    echo "Dieser Wettkampf befindet sich bereits in der DB !";
    echo "<br><br>Wettkampf <a href='002zweiteLiga2004.php?force=1&loeschid=" . $schonda . "'>l&ouml;schen und neu anlegen</a>";
    
    include ('../user/user_footer.html');
    exit;

    }
} elseif($force==1) {

    echo "<br>l&ouml;sche Eintr&auml;ge aus <i>wettkampf</i>, ";
    $sprech = "DELETE FROM wettkampf WHERE id = $loeschid";
    $reselt = mysql_query($sprech, $db);
    
    echo "<i>wettkampf_team</i>, ";
    $sprech = "DELETE FROM wettkampf_team WHERE wettkampf_id = $loeschid";
    $reselt = mysql_query($sprech, $db);

    echo "<i>liga_spiel</i>.. ";
    $sprech = "DELETE FROM liga_spiel WHERE wettkampf_id = $loeschid";
    $reselt = mysql_query($sprech, $db);
    echo ".. fertig !<br><br>";
    
}


echo "<h1 $center>Datenbank-Update</h1>";
echo "<h2 $center>f&uuml;r Spielpaarungen der 2. Bundesliga</h1>";

# Dump of table wettkampf
# ------------------------------------------------------------
echo "<p $center>";


echo "<br>F&uuml;ge Wettkampf hinzu....";
$sprich = " INSERT INTO wettkampf ("; if ($force==1) $sprich .= "id, ";
$sprich .= "saison , liga_art_id , done , spieltage , akt_spieltag , winner_team)";
$sprich .= " VALUES ("; if ($force==1) $sprich .= "'$loeschid', ";
$sprich .= "'2004/2005' , '4' , '0' , '34' , '1' , '0')"; 
$resilt = mysql_query($sprich, $db);
$dieaktuelle = mysql_insert_id();
echo ".....[fertig]";



echo "<br>F&uuml;ge Spielpaarungen hinzu....";
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '24' , NULL , '2005-03-06 00:00:00' , '18' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '7' , NULL , '2004-10-03 00:00:00' , '109' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '29' , NULL , '2005-04-17 00:00:00' , '10' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '12' , NULL , '2004-11-07 00:00:00' , '109' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '27' , NULL , '2005-04-03 00:00:00' , '10' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '10' , NULL , '2004-10-27 00:00:00' , '18' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '32' , NULL , '2005-05-08 00:00:00' , '10' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '15' , NULL , '2004-11-28 00:00:00' , '89' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '26' , NULL , '2005-03-20 00:00:00' , '109' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '9' , NULL , '2004-10-24 00:00:00' , '89' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '22' , NULL , '2005-02-20 00:00:00' , '18' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '5' , NULL , '2004-09-19 00:00:00' , '89' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '28' , NULL , '2005-04-10 00:00:00' , '108' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '11' , NULL , '2004-10-31 00:00:00' , '10' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '25' , NULL , '2005-03-13 00:00:00' , '109' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '8' , NULL , '2004-10-17 00:00:00' , '108' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '24' , NULL , '2005-03-06 00:00:00' , '108' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '7' , NULL , '2004-10-03 00:00:00' , '89' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '23' , NULL , '2005-02-27 00:00:00' , '108' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '6' , NULL , '2004-09-26 00:00:00' , '18' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '25' , NULL , '2005-03-13 00:00:00' , '10' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '8' , NULL , '2004-10-17 00:00:00' , '87' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '22' , NULL , '2005-02-20 00:00:00' , '87' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '5' , NULL , '2004-09-19 00:00:00' , '109' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '21' , NULL , '2005-02-13 00:00:00' , '108' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '4' , NULL , '2004-09-12 00:00:00' , '87' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '20' , NULL , '2005-02-06 00:00:00' , '87' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '3' , NULL , '2004-08-29 00:00:00' , '18' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '18' , NULL , '2005-01-23 00:00:00' , '87' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '1' , NULL , '2004-08-08 00:00:00' , '89' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '34' , NULL , '2005-05-22 00:00:00' , '109' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '17' , NULL , '2004-12-12 00:00:00' , '95' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '33' , NULL , '2005-05-15 00:00:00' , '95' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '16' , NULL , '2004-12-05 00:00:00' , '108' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '32' , NULL , '2005-05-08 00:00:00' , '18' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '15' , NULL , '2004-11-28 00:00:00' , '95' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '30' , NULL , '2005-04-24 00:00:00' , '87' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '13' , NULL , '2004-11-14 00:00:00' , '95' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '25' , NULL , '2005-03-13 00:00:00' , '89' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '8' , NULL , '2004-10-17 00:00:00' , '95' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '20' , NULL , '2005-02-06 00:00:00' , '95' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '3' , NULL , '2004-08-29 00:00:00' , '10' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '33' , NULL , '2005-05-15 00:00:00' , '14' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '16' , NULL , '2004-12-05 00:00:00' , '87' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '31' , NULL , '2005-05-01 00:00:00' , '89' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '14' , NULL , '2004-11-21 00:00:00' , '14' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '28' , NULL , '2005-04-10 00:00:00' , '14' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '11' , NULL , '2004-10-31 00:00:00' , '95' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '23' , NULL , '2005-02-27 00:00:00' , '10' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '6' , NULL , '2004-09-26 00:00:00' , '14' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '20' , NULL , '2005-02-06 00:00:00' , '14' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '3' , NULL , '2004-08-29 00:00:00' , '109' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '19' , NULL , '2005-01-30 00:00:00' , '108' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '2' , NULL , '2004-08-15 00:00:00' , '14' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '18' , NULL , '2005-01-23 00:00:00' , '14' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '1' , NULL , '2004-08-08 00:00:00' , '18' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '33' , NULL , '2005-05-15 00:00:00' , '112' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '16' , NULL , '2004-12-05 00:00:00' , '109' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '32' , NULL , '2005-05-08 00:00:00' , '108' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '15' , NULL , '2004-11-28 00:00:00' , '112' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '31' , NULL , '2005-05-01 00:00:00' , '112' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '14' , NULL , '2004-11-21 00:00:00' , '18' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '29' , NULL , '2005-04-17 00:00:00' , '112' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '12' , NULL , '2004-11-07 00:00:00' , '87' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '27' , NULL , '2005-04-03 00:00:00' , '112' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '10' , NULL , '2004-10-27 00:00:00' , '14' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '24' , NULL , '2005-03-06 00:00:00' , '95' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '7' , NULL , '2004-10-03 00:00:00' , '112' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '23' , NULL , '2005-02-27 00:00:00' , '89' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '6' , NULL , '2004-09-26 00:00:00' , '112' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '19' , NULL , '2005-01-30 00:00:00' , '10' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '2' , NULL , '2004-08-15 00:00:00' , '112' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '34' , NULL , '2005-05-22 00:00:00' , '89' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '17' , NULL , '2004-12-12 00:00:00' , '92' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '33' , NULL , '2005-05-15 00:00:00' , '92' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '16' , NULL , '2004-12-05 00:00:00' , '10' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '30' , NULL , '2005-04-24 00:00:00' , '109' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '13' , NULL , '2004-11-14 00:00:00' , '92' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '29' , NULL , '2005-04-17 00:00:00' , '92' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '12' , NULL , '2004-11-07 00:00:00' , '108' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '28' , NULL , '2005-04-10 00:00:00' , '18' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '11' , NULL , '2004-10-31 00:00:00' , '92' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '26' , NULL , '2005-03-20 00:00:00' , '87' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '9' , NULL , '2004-10-24 00:00:00' , '92' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '24' , NULL , '2005-03-06 00:00:00' , '14' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '7' , NULL , '2004-10-03 00:00:00' , '92' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '21' , NULL , '2005-02-13 00:00:00' , '92' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '4' , NULL , '2004-09-12 00:00:00' , '95' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '20' , NULL , '2005-02-06 00:00:00' , '112' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '3' , NULL , '2004-08-29 00:00:00' , '92' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '34' , NULL , '2005-05-22 00:00:00' , '100' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '17' , NULL , '2004-12-12 00:00:00' , '14' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '31' , NULL , '2005-05-01 00:00:00' , '95' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '14' , NULL , '2004-11-21 00:00:00' , '100' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '30' , NULL , '2005-04-24 00:00:00' , '100' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '13' , NULL , '2004-11-14 00:00:00' , '112' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '27' , NULL , '2005-04-03 00:00:00' , '92' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '10' , NULL , '2004-10-27 00:00:00' , '100' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '26' , NULL , '2005-03-20 00:00:00' , '100' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '9' , NULL , '2004-10-24 00:00:00' , '10' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '23' , NULL , '2005-02-27 00:00:00' , '109' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '6' , NULL , '2004-09-26 00:00:00' , '100' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '22' , NULL , '2005-02-20 00:00:00' , '100' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '5' , NULL , '2004-09-19 00:00:00' , '108' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '21' , NULL , '2005-02-13 00:00:00' , '18' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '4' , NULL , '2004-09-12 00:00:00' , '100' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '20' , NULL , '2005-02-06 00:00:00' , '100' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '3' , NULL , '2004-08-29 00:00:00' , '89' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '19' , NULL , '2005-01-30 00:00:00' , '100' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '2' , NULL , '2004-08-15 00:00:00' , '87' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '34' , NULL , '2005-05-22 00:00:00' , '10' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '17' , NULL , '2004-12-12 00:00:00' , '99' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '31' , NULL , '2005-05-01 00:00:00' , '99' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '14' , NULL , '2004-11-21 00:00:00' , '109' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '30' , NULL , '2005-04-24 00:00:00' , '108' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '13' , NULL , '2004-11-14 00:00:00' , '99' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '29' , NULL , '2005-04-17 00:00:00' , '99' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '12' , NULL , '2004-11-07 00:00:00' , '18' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '28' , NULL , '2005-04-10 00:00:00' , '100' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '11' , NULL , '2004-10-31 00:00:00' , '99' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '27' , NULL , '2005-04-03 00:00:00' , '99' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '10' , NULL , '2004-10-27 00:00:00' , '87' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '25' , NULL , '2005-03-13 00:00:00' , '99' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '8' , NULL , '2004-10-17 00:00:00' , '14' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '22' , NULL , '2005-02-20 00:00:00' , '95' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '5' , NULL , '2004-09-19 00:00:00' , '99' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '21' , NULL , '2005-02-13 00:00:00' , '99' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '4' , NULL , '2004-09-12 00:00:00' , '112' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '19' , NULL , '2005-01-30 00:00:00' , '89' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '2' , NULL , '2004-08-15 00:00:00' , '99' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '18' , NULL , '2005-01-23 00:00:00' , '99' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '1' , NULL , '2004-08-08 00:00:00' , '92' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '34' , NULL , '2005-05-22 00:00:00' , '18' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '17' , NULL , '2004-12-12 00:00:00' , '93' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '33' , NULL , '2005-05-15 00:00:00' , '93' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '16' , NULL , '2004-12-05 00:00:00' , '100' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '32' , NULL , '2005-05-08 00:00:00' , '87' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '15' , NULL , '2004-11-28 00:00:00' , '93' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '30' , NULL , '2005-04-24 00:00:00' , '14' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '13' , NULL , '2004-11-14 00:00:00' , '93' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '29' , NULL , '2005-04-17 00:00:00' , '89' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '12' , NULL , '2004-11-07 00:00:00' , '93' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '27' , NULL , '2005-04-03 00:00:00' , '95' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '10' , NULL , '2004-10-27 00:00:00' , '93' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '26' , NULL , '2005-03-20 00:00:00' , '93' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '9' , NULL , '2004-10-24 00:00:00' , '112' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '24' , NULL , '2005-03-06 00:00:00' , '93' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '7' , NULL , '2004-10-03 00:00:00' , '99' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '23' , NULL , '2005-02-27 00:00:00' , '92' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '6' , NULL , '2004-09-26 00:00:00' , '93' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '22' , NULL , '2005-02-20 00:00:00' , '93' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '5' , NULL , '2004-09-19 00:00:00' , '10' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '19' , NULL , '2005-01-30 00:00:00' , '109' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '2' , NULL , '2004-08-15 00:00:00' , '93' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '18' , NULL , '2005-01-23 00:00:00' , '93' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '1' , NULL , '2004-08-08 00:00:00' , '108' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '34' , NULL , '2005-05-22 00:00:00' , '108' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '17' , NULL , '2004-12-12 00:00:00' , '110' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '33' , NULL , '2005-05-15 00:00:00' , '110' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '16' , NULL , '2004-12-05 00:00:00' , '18' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '32' , NULL , '2005-05-08 00:00:00' , '100' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '15' , NULL , '2004-11-28 00:00:00' , '110' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '31' , NULL , '2005-05-01 00:00:00' , '110' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '14' , NULL , '2004-11-21 00:00:00' , '87' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '29' , NULL , '2005-04-17 00:00:00' , '110' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '12' , NULL , '2004-11-07 00:00:00' , '14' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '28' , NULL , '2005-04-10 00:00:00' , '93' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '11' , NULL , '2004-10-31 00:00:00' , '110' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '27' , NULL , '2005-04-03 00:00:00' , '89' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '10' , NULL , '2004-10-27 00:00:00' , '110' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '26' , NULL , '2005-03-20 00:00:00' , '110' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '9' , NULL , '2004-10-24 00:00:00' , '95' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '25' , NULL , '2005-03-13 00:00:00' , '112' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '8' , NULL , '2004-10-17 00:00:00' , '110' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '23' , NULL , '2005-02-27 00:00:00' , '99' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '6' , NULL , '2004-09-26 00:00:00' , '110' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '22' , NULL , '2005-02-20 00:00:00' , '110' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '5' , NULL , '2004-09-19 00:00:00' , '92' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '21' , NULL , '2005-02-13 00:00:00' , '10' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '4' , NULL , '2004-09-12 00:00:00' , '110' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '18' , NULL , '2005-01-23 00:00:00' , '110' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '1' , NULL , '2004-08-08 00:00:00' , '109' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '33' , NULL , '2005-05-15 00:00:00' , '99' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '16' , NULL , '2004-12-05 00:00:00' , '111' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '32' , NULL , '2005-05-08 00:00:00' , '111' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '15' , NULL , '2004-11-28 00:00:00' , '92' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '31' , NULL , '2005-05-01 00:00:00' , '10' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '14' , NULL , '2004-11-21 00:00:00' , '111' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '30' , NULL , '2005-04-24 00:00:00' , '111' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '13' , NULL , '2004-11-14 00:00:00' , '89' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '28' , NULL , '2005-04-10 00:00:00' , '109' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '11' , NULL , '2004-10-31 00:00:00' , '111' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '27' , NULL , '2005-04-03 00:00:00' , '111' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '10' , NULL , '2004-10-27 00:00:00' , '108' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '26' , NULL , '2005-03-20 00:00:00' , '18' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '9' , NULL , '2004-10-24 00:00:00' , '111' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '25' , NULL , '2005-03-13 00:00:00' , '111' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '8' , NULL , '2004-10-17 00:00:00' , '100' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '24' , NULL , '2005-03-06 00:00:00' , '87' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '7' , NULL , '2004-10-03 00:00:00' , '111' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '22' , NULL , '2005-02-20 00:00:00' , '14' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '5' , NULL , '2004-09-19 00:00:00' , '111' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '21' , NULL , '2005-02-13 00:00:00' , '111' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '4' , NULL , '2004-09-12 00:00:00' , '93' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '20' , NULL , '2005-02-06 00:00:00' , '110' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '3' , NULL , '2004-08-29 00:00:00' , '111' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '19' , NULL , '2005-01-30 00:00:00' , '111' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '2' , NULL , '2004-08-15 00:00:00' , '95' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '18' , NULL , '2005-01-23 00:00:00' , '112' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '1' , NULL , '2004-08-08 00:00:00' , '111' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '34' , NULL , '2005-05-22 00:00:00' , '90' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '17' , NULL , '2004-12-12 00:00:00' , '112' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '32' , NULL , '2005-05-08 00:00:00' , '90' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '15' , NULL , '2004-11-28 00:00:00' , '99' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '31' , NULL , '2005-05-01 00:00:00' , '92' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '14' , NULL , '2004-11-21 00:00:00' , '90' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '30' , NULL , '2005-04-24 00:00:00' , '90' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '13' , NULL , '2004-11-14 00:00:00' , '10' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '29' , NULL , '2005-04-17 00:00:00' , '111' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '12' , NULL , '2004-11-07 00:00:00' , '90' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '28' , NULL , '2005-04-10 00:00:00' , '90' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '11' , NULL , '2004-10-31 00:00:00' , '89' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '27' , NULL , '2005-04-03 00:00:00' , '90' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '10' , NULL , '2004-10-27 00:00:00' , '109' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '26' , NULL , '2005-03-20 00:00:00' , '108' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '9' , NULL , '2004-10-24 00:00:00' , '90' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '25' , NULL , '2005-03-13 00:00:00' , '90' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '8' , NULL , '2004-10-17 00:00:00' , '18' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '24' , NULL , '2005-03-06 00:00:00' , '100' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '7' , NULL , '2004-10-03 00:00:00' , '90' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '23' , NULL , '2005-02-27 00:00:00' , '90' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '6' , NULL , '2004-09-26 00:00:00' , '87' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '21' , NULL , '2005-02-13 00:00:00' , '90' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '4' , NULL , '2004-09-12 00:00:00' , '14' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '20' , NULL , '2005-02-06 00:00:00' , '93' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '3' , NULL , '2004-08-29 00:00:00' , '90' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '19' , NULL , '2005-01-30 00:00:00' , '90' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '2' , NULL , '2004-08-15 00:00:00' , '110' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '18' , NULL , '2005-01-23 00:00:00' , '95' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '1' , NULL , '2004-08-08 00:00:00' , '90' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '34' , NULL , '2005-05-22 00:00:00' , '111' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '17' , NULL , '2004-12-12 00:00:00' , '107' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '33' , NULL , '2005-05-15 00:00:00' , '107' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '16' , NULL , '2004-12-05 00:00:00' , '90' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '32' , NULL , '2005-05-08 00:00:00' , '109' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '15' , NULL , '2004-11-28 00:00:00' , '107' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '31' , NULL , '2005-05-01 00:00:00' , '107' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '14' , NULL , '2004-11-21 00:00:00' , '108' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '30' , NULL , '2005-04-24 00:00:00' , '18' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '13' , NULL , '2004-11-14 00:00:00' , '107' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '29' , NULL , '2005-04-17 00:00:00' , '107' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '12' , NULL , '2004-11-07 00:00:00' , '100' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '28' , NULL , '2005-04-10 00:00:00' , '87' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '11' , NULL , '2004-10-31 00:00:00' , '107' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '26' , NULL , '2005-03-20 00:00:00' , '14' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '9' , NULL , '2004-10-24 00:00:00' , '107' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '25' , NULL , '2005-03-13 00:00:00' , '107' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '8' , NULL , '2004-10-17 00:00:00' , '93' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '24' , NULL , '2005-03-06 00:00:00' , '110' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '7' , NULL , '2004-10-03 00:00:00' , '107' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '23' , NULL , '2005-02-27 00:00:00' , '107' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '6' , NULL , '2004-09-26 00:00:00' , '95' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '22' , NULL , '2005-02-20 00:00:00' , '112' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '5' , NULL , '2004-09-19 00:00:00' , '107' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '21' , NULL , '2005-02-13 00:00:00' , '89' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '4' , NULL , '2004-09-12 00:00:00' , '107' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '20' , NULL , '2005-02-06 00:00:00' , '107' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '3' , NULL , '2004-08-29 00:00:00' , '99' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '19' , NULL , '2005-01-30 00:00:00' , '92' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '2' , NULL , '2004-08-15 00:00:00' , '107' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '18' , NULL , '2005-01-23 00:00:00' , '107' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '1' , NULL , '2004-08-08 00:00:00' , '10' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '34' , NULL , '2005-05-22 00:00:00' , '87' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '17' , NULL , '2004-12-12 00:00:00' , '94' , '87' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '33' , NULL , '2005-05-15 00:00:00' , '94' , '89' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '16' , NULL , '2004-12-05 00:00:00' , '89' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '32' , NULL , '2005-05-08 00:00:00' , '94' , '14' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '15' , NULL , '2004-11-28 00:00:00' , '14' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '31' , NULL , '2005-05-01 00:00:00' , '93' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '14' , NULL , '2004-11-21 00:00:00' , '94' , '93' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '30' , NULL , '2005-04-24 00:00:00' , '94' , '110' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '13' , NULL , '2004-11-14 00:00:00' , '110' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '29' , NULL , '2005-04-17 00:00:00' , '95' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '12' , NULL , '2004-11-07 00:00:00' , '94' , '95' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '28' , NULL , '2005-04-10 00:00:00' , '94' , '112' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '11' , NULL , '2004-10-31 00:00:00' , '112' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '27' , NULL , '2005-04-03 00:00:00' , '107' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '10' , NULL , '2004-10-27 00:00:00' , '94' , '107' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '26' , NULL , '2005-03-20 00:00:00' , '94' , '99' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '9' , NULL , '2004-10-24 00:00:00' , '99' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '25' , NULL , '2005-03-13 00:00:00' , '92' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '8' , NULL , '2004-10-17 00:00:00' , '94' , '92' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '24' , NULL , '2005-03-06 00:00:00' , '94' , '10' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '7' , NULL , '2004-10-03 00:00:00' , '10' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '23' , NULL , '2005-02-27 00:00:00' , '111' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '6' , NULL , '2004-09-26 00:00:00' , '94' , '111' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '22' , NULL , '2005-02-20 00:00:00' , '94' , '90' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '5' , NULL , '2004-09-19 00:00:00' , '90' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '21' , NULL , '2005-02-13 00:00:00' , '109' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '4' , NULL , '2004-09-12 00:00:00' , '94' , '109' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '20' , NULL , '2005-02-06 00:00:00' , '94' , '108' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '3' , NULL , '2004-08-29 00:00:00' , '108' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '19' , NULL , '2005-01-30 00:00:00' , '18' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '2' , NULL , '2004-08-15 00:00:00' , '94' , '18' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '18' , NULL , '2005-01-23 00:00:00' , '94' , '100' , '0')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO liga_spiel (wettkampf_id , spieltag , gruppe , datum , heim_team_id , gast_team_id , done) VALUES ('$dieaktuelle' , '1' , NULL , '2004-08-08 00:00:00' , '100' , '94' , '0')"; $resilt = mysql_query($sprich, $db);
echo ".....[fertig]";




echo "<br>F&uuml;ge teilnehmende Mannschaften hinzu....";

# Dump of table wettkampf_team
# ------------------------------------------------------------

$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '94' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '107' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '90' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '111' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '110' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '93' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '99' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '100' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '92' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '112' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '14' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '95' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '87' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '108' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '89' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '10' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '18' , '')"; $resilt = mysql_query($sprich, $db);
$sprich = " INSERT INTO wettkampf_team (wettkampf_id , team_id , gruppe) VALUES ('$dieaktuelle' , '109' , '')"; $resilt = mysql_query($sprich, $db);
echo ".....[fertig]";







echo "<br><br><br><br>Ich bin fertig.";


include ('../user/user_footer.html');
?>







